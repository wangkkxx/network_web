$(function(){
    $(".servers li.lr a").hover(function(){
        
    })
})